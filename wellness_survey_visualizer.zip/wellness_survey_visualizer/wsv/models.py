"""Core data model and domain constraints."""
from dataclasses import dataclass, asdict

GROUPS = ["Student", "Staff", "Faculty", "Community", "Other"]
LIMITS = {
    "mood": (1, 10),
    "stress": (1, 10),
    "sleep_hours": (0.0, 24.0),
    "activity_minutes": (0, 600),
}
MAX_COMMENT = 200
FIELDS = ["id", "date", "group", "mood", "stress", "sleep_hours", "activity_minutes", "comment"]


@dataclass
class SurveyResponse:
    """One anonymous survey response (no names or contact details stored)."""
    id: int
    date: str            # YYYY-MM-DD
    group: str           # one of GROUPS
    mood: int            # 1 (very low) .. 10 (excellent)
    stress: int          # 1 (calm) .. 10 (extreme)
    sleep_hours: float   # average hours slept last night
    activity_minutes: int
    comment: str = ""

    def to_dict(self) -> dict:
        return asdict(self)
