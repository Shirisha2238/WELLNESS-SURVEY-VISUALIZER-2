"""Matplotlib charts (saved as PNG). Degrades gracefully if matplotlib is missing."""
import os
from typing import Dict, List

try:
    import matplotlib
    matplotlib.use("Agg")           # headless-safe: render straight to files
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except ImportError:                 # fallback path required by the brief
    HAVE_MPL = False


def make_charts(s: Dict, outdir: str = "exports") -> List[str]:
    """Create trend, mood-distribution and by-group charts. Returns file paths."""
    if not HAVE_MPL:
        raise ImportError("matplotlib is not installed (pip install matplotlib)")
    if not s.get("count"):
        return []
    os.makedirs(outdir, exist_ok=True)
    files = []

    weeks = [w[0] for w in s["weekly"]]
    vals = [w[1] for w in s["weekly"]]
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(weeks, vals, marker="o", color="#2a7de1")
    ax.axhline(70, color="green", ls="--", lw=1, label="Good (70)")
    ax.axhline(50, color="orange", ls="--", lw=1, label="Fair (50)")
    ax.set_ylim(0, 100)
    ax.set_title(f"Weekly Wellness Index - {s['trend']}")
    ax.set_ylabel("Average index")
    ax.legend()
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    fig.tight_layout()
    p = os.path.join(outdir, "trend.png"); fig.savefig(p, dpi=120); plt.close(fig); files.append(p)

    fig, ax = plt.subplots(figsize=(7, 4))
    dist = s["mood_distribution"]
    ax.bar(list(dist.keys()), list(dist.values()), color="#5cb85c")
    ax.set_xticks(list(dist.keys()))
    ax.set_title("Mood Distribution"); ax.set_xlabel("Mood score"); ax.set_ylabel("Responses")
    fig.tight_layout()
    p = os.path.join(outdir, "mood_distribution.png"); fig.savefig(p, dpi=120); plt.close(fig); files.append(p)

    fig, ax = plt.subplots(figsize=(7, 4))
    names = list(s["groups"].keys())
    ax.bar(names, [s["groups"][n]["index"] for n in names], color="#f0ad4e")
    ax.set_ylim(0, 100)
    ax.set_title("Wellness Index by Group"); ax.set_ylabel("Average index")
    fig.tight_layout()
    p = os.path.join(outdir, "by_group.png"); fig.savefig(p, dpi=120); plt.close(fig); files.append(p)
    return files
