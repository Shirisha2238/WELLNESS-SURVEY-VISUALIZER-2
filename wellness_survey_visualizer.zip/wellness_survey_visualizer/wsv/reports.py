"""Executive summary text + multi-format export (Markdown, plain-text audit log, CSV)."""
import csv
import datetime as dt
import os
from typing import Dict, List

from .analytics import status, warnings, wellness_index
from .models import SurveyResponse


def summary_lines(s: Dict) -> List[str]:
    if not s.get("count"):
        return ["No data available."]
    lines = [
        f"Responses analysed : {s['count']}  ({s['date_range'][0]} to {s['date_range'][1]})",
        f"Average mood       : {s['avg_mood']} / 10",
        f"Average stress     : {s['avg_stress']} / 10",
        f"Average sleep      : {s['avg_sleep']} h",
        f"Average activity   : {s['avg_activity']} min/day",
        f"Wellness index     : {s['avg_index']} / 100  -> {s['overall_status']}",
        f"Status breakdown   : " + ", ".join(f"{k}: {v}" for k, v in s["status_counts"].items()),
        f"Trend              : {s['trend']}",
    ]
    return lines


def _stamp() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M")


def export_markdown(records: List[SurveyResponse], s: Dict, path: str, chart_files: List[str] = ()) -> str:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    out = ["# Wellness Survey Report", f"_Generated {_stamp()}_", "", "## Executive Summary", ""]
    out += [f"- {l}" for l in summary_lines(s)]
    if s.get("count"):
        out += ["", "## By Group", "", "| Group | Responses | Avg mood | Avg stress | Index |", "|---|---|---|---|---|"]
        for g, v in s["groups"].items():
            out.append(f"| {g} | {v['count']} | {v['mood']} | {v['stress']} | {v['index']} |")
        out += ["", "## Weekly Trend", "", "| Week | Avg index | Responses |", "|---|---|---|"]
        out += [f"| {w} | {a} | {n} |" for w, a, n in s["weekly"]]
        flags = warnings(records)
        out += ["", f"## Warnings ({len(flags)})", ""]
        out += [f"- Record #{i}: {m}" for i, m in flags] or ["- None"]
    for f in chart_files:
        out += ["", f"![{os.path.basename(f)}]({os.path.basename(f)})"]
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(out) + "\n")
    return path


def export_audit_log(records: List[SurveyResponse], s: Dict, path: str) -> str:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(f"WELLNESS SURVEY AUDIT LOG - {_stamp()}\n{'=' * 50}\n")
        fh.write("\n".join(summary_lines(s)) + "\n\nWARNINGS\n--------\n")
        flags = warnings(records)
        fh.writelines(f"record {i}: {m}\n" for i, m in flags)
        if not flags:
            fh.write("none\n")
        fh.write("\nRECORDS\n-------\n")
        for r in records:
            idx = wellness_index(r)
            fh.write(f"#{r.id} {r.date} {r.group} mood={r.mood} stress={r.stress} "
                     f"sleep={r.sleep_hours} activity={r.activity_minutes} index={idx} ({status(idx)})\n")
    return path


def export_summary_csv(records: List[SurveyResponse], path: str) -> str:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "date", "group", "mood", "stress", "sleep_hours", "activity_minutes", "wellness_index", "status"])
        for r in records:
            idx = wellness_index(r)
            w.writerow([r.id, r.date, r.group, r.mood, r.stress, r.sleep_hours, r.activity_minutes, idx, status(idx)])
    return path
