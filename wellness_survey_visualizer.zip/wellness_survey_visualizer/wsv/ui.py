"""Terminal helpers: ANSI colours, tables, pagination, and loop-until-valid input wrappers."""
import os
import sys
from typing import Callable, List, Sequence

USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None
CODES = {"red": "31", "green": "32", "yellow": "33", "blue": "34", "cyan": "36", "bold": "1", "dim": "2"}


def c(text: str, *styles: str) -> str:
    if not USE_COLOR:
        return str(text)
    return "".join(f"\033[{CODES[s]}m" for s in styles) + str(text) + "\033[0m"


STATUS_COLOR = {"Good": "green", "Fair": "yellow", "At Risk": "red"}


def banner() -> None:
    line = "=" * 56
    print(c(line, "cyan"))
    print(c("   WELLNESS SURVEY VISUALIZER", "bold", "cyan"))
    print(c("   LocalImpact Challenge | Health & Wellbeing", "dim"))
    print(c("   Anonymous survey analysis - stored locally", "dim"))
    print(c(line, "cyan"))


def heading(text: str) -> None:
    print("\n" + c(f"--- {text} ---", "bold", "blue"))


def table(headers: Sequence[str], rows: List[Sequence], widths: Sequence[int] = None) -> str:
    rows = [[str(x) for x in r] for r in rows]
    if widths is None:
        widths = [max(len(h), *(len(r[i]) for r in rows)) if rows else len(h) for i, h in enumerate(headers)]
        widths = [min(w, 40) for w in widths]
    def fmt(r):
        return " | ".join((v if len(v) <= w else v[: w - 1] + "…").ljust(w) for v, w in zip(r, widths))
    sep = "-+-".join("-" * w for w in widths)
    return "\n".join([fmt(headers), sep] + [fmt(r) for r in rows])


def paginate(headers, rows, page_size: int = 15) -> None:
    if not rows:
        print("No records to show.")
        return
    total = (len(rows) + page_size - 1) // page_size
    for p in range(total):
        chunk = rows[p * page_size:(p + 1) * page_size]
        print(table(headers, chunk))
        print(c(f"Page {p + 1}/{total} - {len(rows)} record(s)", "dim"))
        if p < total - 1:
            if input("Enter = next page, q = stop: ").strip().lower() == "q":
                break


def ask(prompt: str, parser: Callable, default=None, allow_blank: bool = False):
    """Loop until `parser(raw)` succeeds. Parser raises ValueError with a friendly message."""
    suffix = f" [{default}]" if default not in (None, "") else ""
    while True:
        raw = input(f"{prompt}{suffix}: ").strip()
        if raw == "":
            if default is not None:
                raw = str(default)
            elif allow_blank:
                return ""
        try:
            return parser(raw)
        except ValueError as exc:
            print(c(f"  ✗ {exc}. Please try again.", "red"))


def confirm(prompt: str) -> bool:
    return input(f"{prompt} (y/n): ").strip().lower() in ("y", "yes")
