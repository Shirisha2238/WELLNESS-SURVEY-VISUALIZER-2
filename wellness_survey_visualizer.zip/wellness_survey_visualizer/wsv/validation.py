"""Defensive validation for raw values (used by the CLI, CSV import and file loading)."""
import datetime as dt
import re
from typing import Optional

from .models import GROUPS, LIMITS, MAX_COMMENT, SurveyResponse

_CTRL = re.compile(r"[\x00-\x1f\x7f]")


def clean_text(text) -> str:
    """Strip control characters and surrounding whitespace."""
    return _CTRL.sub(" ", str(text or "")).strip()


def parse_int(value, lo: int, hi: int, name: str) -> int:
    try:
        text = str(value).strip()
        if "." in text:                      # allow "7.0" but not "7.5"
            f = float(text)
            if f != int(f):
                raise ValueError
            text = str(int(f))
        n = int(text)
    except (ValueError, TypeError, OverflowError):
        raise ValueError(f"{name} must be a whole number")
    if not lo <= n <= hi:
        raise ValueError(f"{name} must be between {lo} and {hi}")
    return n


def parse_float(value, lo: float, hi: float, name: str) -> float:
    try:
        n = float(str(value).strip())
    except (ValueError, TypeError):
        raise ValueError(f"{name} must be a number")
    if n != n or n in (float("inf"), float("-inf")):
        raise ValueError(f"{name} must be a finite number")
    if not lo <= n <= hi:
        raise ValueError(f"{name} must be between {lo} and {hi}")
    return round(n, 1)


def parse_date(value, allow_future: bool = False) -> str:
    try:
        d = dt.date.fromisoformat(str(value).strip())
    except ValueError:
        raise ValueError("date must be in YYYY-MM-DD format")
    if d < dt.date(2000, 1, 1):
        raise ValueError("date is too far in the past")
    if not allow_future and d > dt.date.today():
        raise ValueError("date cannot be in the future")
    return d.isoformat()


def parse_group(value) -> str:
    text = str(value).strip().lower()
    for g in GROUPS:
        if g.lower() == text:
            return g
    if text.isdigit() and 1 <= int(text) <= len(GROUPS):
        return GROUPS[int(text) - 1]
    raise ValueError(f"group must be one of: {', '.join(GROUPS)}")


def parse_comment(value) -> str:
    text = clean_text(value)
    if len(text) > MAX_COMMENT:
        raise ValueError(f"comment must be at most {MAX_COMMENT} characters")
    return text


def validate_record(raw: dict, record_id: Optional[int] = None):
    """Validate a raw dict. Returns (SurveyResponse | None, [error messages])."""
    errors = []

    def attempt(fn, *args):
        try:
            return fn(*args)
        except ValueError as exc:
            errors.append(str(exc))
            return None

    date = attempt(parse_date, raw.get("date"))
    group = attempt(parse_group, raw.get("group"))
    mood = attempt(parse_int, raw.get("mood"), *LIMITS["mood"], "mood")
    stress = attempt(parse_int, raw.get("stress"), *LIMITS["stress"], "stress")
    sleep = attempt(parse_float, raw.get("sleep_hours"), *LIMITS["sleep_hours"], "sleep_hours")
    act = attempt(parse_int, raw.get("activity_minutes"), *LIMITS["activity_minutes"], "activity_minutes")
    comment = attempt(parse_comment, raw.get("comment", ""))
    rid = record_id
    if rid is None and str(raw.get("id", "") or "").strip():
        rid = attempt(parse_int, raw.get("id"), 1, 10**9, "id")
    if errors:
        return None, errors
    return SurveyResponse(rid or 0, date, group, mood, stress, sleep, act, comment), []
