"""Core logic: wellness index, summaries, trends, warnings, search."""
import datetime as dt
from collections import defaultdict
from statistics import mean
from typing import Dict, List, Optional

from .models import SurveyResponse

THRESHOLDS = {"good": 70.0, "fair": 50.0}


def wellness_index(r: SurveyResponse) -> float:
    """0-100 composite: mood 30%, low stress 30%, sleep 20%, activity 20%."""
    mood_s = (r.mood - 1) / 9 * 100
    stress_s = (10 - r.stress) / 9 * 100
    if 7 <= r.sleep_hours <= 9:
        sleep_s = 100.0
    else:
        gap = 7 - r.sleep_hours if r.sleep_hours < 7 else r.sleep_hours - 9
        sleep_s = max(0.0, 100 - gap * 25)
    act_s = min(r.activity_minutes / 30, 1) * 100
    return round(0.3 * mood_s + 0.3 * stress_s + 0.2 * sleep_s + 0.2 * act_s, 1)


def status(index: float) -> str:
    if index >= THRESHOLDS["good"]:
        return "Good"
    if index >= THRESHOLDS["fair"]:
        return "Fair"
    return "At Risk"


def _avg(values) -> float:
    values = list(values)
    return round(mean(values), 2) if values else 0.0


def weekly_trend(records: List[SurveyResponse]) -> List[tuple]:
    """[(ISO week label, average index, count)] in chronological order."""
    buckets = defaultdict(list)
    for r in records:
        y, w, _ = dt.date.fromisoformat(r.date).isocalendar()
        buckets[f"{y}-W{w:02d}"].append(wellness_index(r))
    return [(k, _avg(v), len(v)) for k, v in sorted(buckets.items())]


def trend_direction(weekly: List[tuple]) -> str:
    """Least-squares slope over weekly averages."""
    if len(weekly) < 2:
        return "Not enough data"
    ys = [w[1] for w in weekly]
    xs = list(range(len(ys)))
    mx, my = mean(xs), mean(ys)
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
    if slope > 0.5:
        return f"Improving (+{slope:.1f} pts/week)"
    if slope < -0.5:
        return f"Declining ({slope:.1f} pts/week)"
    return f"Stable ({slope:+.1f} pts/week)"


def summarize(records: List[SurveyResponse]) -> Dict:
    if not records:
        return {"count": 0}
    idx = [wellness_index(r) for r in records]
    by_group = defaultdict(list)
    for r, i in zip(records, idx):
        by_group[r.group].append((r, i))
    groups = {
        g: {"count": len(v), "mood": _avg(r.mood for r, _ in v),
            "stress": _avg(r.stress for r, _ in v), "index": _avg(i for _, i in v)}
        for g, v in sorted(by_group.items())
    }
    status_counts = {"Good": 0, "Fair": 0, "At Risk": 0}
    for i in idx:
        status_counts[status(i)] += 1
    weekly = weekly_trend(records)
    avg_index = _avg(idx)
    return {
        "count": len(records),
        "date_range": (min(r.date for r in records), max(r.date for r in records)),
        "avg_mood": _avg(r.mood for r in records),
        "avg_stress": _avg(r.stress for r in records),
        "avg_sleep": _avg(r.sleep_hours for r in records),
        "avg_activity": _avg(r.activity_minutes for r in records),
        "avg_index": avg_index,
        "overall_status": status(avg_index),
        "status_counts": status_counts,
        "groups": groups,
        "weekly": weekly,
        "trend": trend_direction(weekly),
        "mood_distribution": {n: sum(1 for r in records if r.mood == n) for n in range(1, 11)},
    }


def warnings(records: List[SurveyResponse]) -> List[tuple]:
    """Threshold and anomaly flags: [(record id, message)]."""
    out = []
    for r in records:
        if r.stress >= 9:
            out.append((r.id, f"Critical stress level ({r.stress}/10)"))
        if r.mood <= 2:
            out.append((r.id, f"Very low mood ({r.mood}/10)"))
        if r.sleep_hours < 4:
            out.append((r.id, f"Severe sleep deficit ({r.sleep_hours} h)"))
        elif r.sleep_hours > 12:
            out.append((r.id, f"Unusually long sleep ({r.sleep_hours} h)"))
        if r.activity_minutes > 300:
            out.append((r.id, f"Anomalous activity value ({r.activity_minutes} min)"))
        if r.mood >= 9 and r.stress >= 9:
            out.append((r.id, "Inconsistent answers (high mood and high stress) - check entry"))
    return out


def search(records: List[SurveyResponse], keyword: str = "", group: Optional[str] = None,
           date_from: Optional[str] = None, date_to: Optional[str] = None,
           status_filter: Optional[str] = None) -> List[SurveyResponse]:
    kw = keyword.strip().lower()
    res = []
    for r in records:
        if kw and kw not in r.comment.lower() and kw not in r.group.lower():
            continue
        if group and r.group != group:
            continue
        if date_from and r.date < date_from:
            continue
        if date_to and r.date > date_to:
            continue
        if status_filter and status(wellness_index(r)) != status_filter:
            continue
        res.append(r)
    return res
