"""Local persistence (JSON primary store, CSV import/export) with corruption handling."""
import csv
import json
import os
import shutil
from typing import List, Tuple

from .models import FIELDS, SurveyResponse
from .validation import validate_record


class Store:
    def __init__(self, path: str = "data/responses.json"):
        self.path = path
        self.records: List[SurveyResponse] = []
        self.load_notes: List[str] = []
        self.load()

    # ---------- JSON persistence ----------
    def load(self) -> None:
        self.records, self.load_notes = [], []
        try:
            with open(self.path, "r", encoding="utf-8") as fh:
                payload = json.load(fh)
            if not isinstance(payload, dict) or not isinstance(payload.get("responses"), list):
                raise ValueError("unexpected file structure")
        except FileNotFoundError:
            self.load_notes.append("No data file found - created a clean one.")
            self.save()
            return
        except (json.JSONDecodeError, ValueError, UnicodeDecodeError) as exc:
            backup = self.path + ".corrupt"
            try:
                shutil.copy(self.path, backup)
                self.load_notes.append(f"Data file was unreadable ({exc}). Backed up to {backup}; starting clean.")
            except OSError:
                self.load_notes.append(f"Data file was unreadable ({exc}); starting clean.")
            self.save()
            return
        skipped = 0
        seen = set()
        for raw in payload["responses"]:
            rec, _errs = validate_record(raw if isinstance(raw, dict) else {})
            if rec is None or rec.id in seen or rec.id == 0:
                skipped += 1
                continue
            seen.add(rec.id)
            self.records.append(rec)
        if skipped:
            self.load_notes.append(f"Skipped {skipped} invalid or duplicate record(s) while loading.")

    def save(self) -> None:
        os.makedirs(os.path.dirname(self.path) or ".", exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump({"version": 1, "responses": [r.to_dict() for r in self.records]}, fh, indent=2)
        os.replace(tmp, self.path)          # atomic: never leaves a half-written file

    # ---------- record operations ----------
    def next_id(self) -> int:
        return max((r.id for r in self.records), default=0) + 1

    def add(self, rec: SurveyResponse) -> SurveyResponse:
        rec.id = self.next_id()
        self.records.append(rec)
        self.save()
        return rec

    def replace_all(self, records: List[SurveyResponse]) -> None:
        self.records = list(records)
        for i, r in enumerate(self.records, 1):
            r.id = i
        self.save()

    # ---------- CSV ----------
    def export_csv(self, path: str) -> str:
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=FIELDS)
            w.writeheader()
            for r in self.records:
                w.writerow(r.to_dict())
        return path

    def import_csv(self, path: str, error_log: str = "exports/import_errors.log") -> Tuple[int, int]:
        """Bulk import. Returns (added, rejected). Row-level problems go to error_log."""
        added, errors = 0, []
        with open(path, "r", newline="", encoding="utf-8-sig") as fh:
            reader = csv.DictReader(fh)
            missing = [c for c in FIELDS[1:7] if c not in (reader.fieldnames or [])]
            if missing:
                raise ValueError(f"CSV is missing required column(s): {', '.join(missing)}")
            for line_no, row in enumerate(reader, start=2):
                rec, errs = validate_record(row)
                if rec is None:
                    errors.append(f"line {line_no}: " + "; ".join(errs))
                    continue
                rec.id = self.next_id()
                self.records.append(rec)
                added += 1
        if added:
            self.save()
        os.makedirs(os.path.dirname(error_log) or ".", exist_ok=True)
        with open(error_log, "w", encoding="utf-8") as fh:
            fh.write("\n".join(errors) if errors else "No errors.")
            fh.write("\n")
        return added, len(errors)
