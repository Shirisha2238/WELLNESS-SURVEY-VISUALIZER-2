"""Generates data/sample_responses.(csv|json) and data/sample_import_with_errors.csv (deterministic)."""
import csv
import json
import random
import datetime as dt

from wsv.models import FIELDS

random.seed(40)
GROUPS = ["Student", "Staff", "Faculty", "Community", "Other"]
COMMENTS = ["", "", "Busy exam week", "Feeling rested", "Too many deadlines", "Enjoyed the walk",
            "Slept badly", "Workload is heavy", "Great week", "Need more breaks"]


def build(n=40):
    start = dt.date.today() - dt.timedelta(days=8 * 7)
    rows = []
    for i in range(n):
        day = start + dt.timedelta(days=int(i * 56 / n))
        drift = i / n * 1.5                         # gentle improving trend for the demo
        mood = max(1, min(10, round(random.gauss(5 + drift, 1.8))))
        stress = max(1, min(10, round(random.gauss(6 - drift, 1.8))))
        rows.append({"id": i + 1, "date": day.isoformat(), "group": random.choice(GROUPS),
                     "mood": mood, "stress": stress, "sleep_hours": round(random.gauss(6.8, 1.3), 1),
                     "activity_minutes": max(0, int(random.gauss(35, 25))), "comment": random.choice(COMMENTS)})
    # deliberate boundary / edge cases (all valid)
    edge = [("Student", 1, 10, 0.0, 0, "Edge: minimum mood, max stress"),
            ("Faculty", 10, 1, 24.0, 600, "Edge: maximum values"),
            ("Staff", 10, 10, 8.0, 60, "Edge: inconsistent answers"),
            ("Other", 2, 9, 3.5, 5, "Edge: multiple warnings")]
    for k, (g, m, s, sl, a, cmt) in enumerate(edge):
        rows.append({"id": len(rows) + 1, "date": (start + dt.timedelta(days=10 + 12 * k)).isoformat(), "group": g, "mood": m,
                     "stress": s, "sleep_hours": sl, "activity_minutes": a, "comment": cmt})
    for i, r in enumerate(rows, 1):
        r["id"] = i
    return rows


def main():
    rows = build()
    with open("data/sample_responses.csv", "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS); w.writeheader(); w.writerows(rows)
    with open("data/sample_responses.json", "w", encoding="utf-8") as fh:
        json.dump({"version": 1, "responses": rows}, fh, indent=2)
    today = dt.date.today().isoformat()
    bad = [
        FIELDS,
        [1, today, "Student", 7, 4, 7.5, 40, "Valid row"],
        [2, today, "Student", 11, 4, 7.5, 40, "mood out of range"],
        [3, "2026-13-45", "Staff", 5, 5, 7, 30, "bad date"],
        [4, today, "Alien", 5, 5, 7, 30, "unknown group"],
        [5, today, "Staff", "abc", 5, 7, 30, "non-numeric mood"],
        [6, today, "Faculty", 6, 5, "", 30, "blank sleep"],
        [7, today, "Other", 6, 5, 7, 30, "Another valid row"],
    ]
    with open("data/sample_import_with_errors.csv", "w", newline="", encoding="utf-8") as fh:
        csv.writer(fh).writerows(bad)
    print(f"Wrote {len(rows)} sample rows + import-error demo file.")


if __name__ == "__main__":
    main()
