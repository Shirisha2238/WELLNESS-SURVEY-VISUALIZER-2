# Wellness Survey Visualizer
LocalImpact Challenge - Project #40 - Health & Wellbeing

A beginner-friendly, menu-driven Python app for analysing **anonymous** wellness survey responses
and charting overall trends. Standard library + Matplotlib only (Python 3.10+).

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python generate_sample_data.py     # (re)creates the 44-row sample datasets in data/
python main.py
```
In the menu choose **9** to load the sample dataset, then explore options 2-7.

## Features (mapped to the brief)
| Brief requirement | Where |
|---|---|
| Interactive terminal menu, ANSI branding | `main.py`, `wsv/ui.py` |
| Defensive validation (type, range, date, group, blank input) | `wsv/validation.py`, `ui.ask()` loops until valid |
| Core logic: wellness index, weekly trend, status, group stats | `wsv/analytics.py` |
| JSON persistence, corrupt/missing file recovery (atomic writes) | `wsv/storage.py` |
| Keyword / group / date / status search | menu 3, `analytics.search()` |
| Executive summary | menu 4 |
| Matplotlib charts (trend, mood distribution, by group) | menu 6, `wsv/charts.py` |
| Markdown + text audit log + CSV export | menu 7, `wsv/reports.py` |
| Threshold warnings / anomaly flags | menu 5 |
| Bulk CSV import with row-by-row error log | menu 8 -> `exports/import_errors.log` |
| Optional GUI | `web_app.py` (Streamlit) |

## Survey fields
`date`, `group` (Student/Staff/Faculty/Community/Other), `mood` 1-10, `stress` 1-10,
`sleep_hours` 0-24, `activity_minutes` 0-600, optional `comment` (<=200 chars). No names or contact details.

**Wellness index (0-100)** = 30% mood + 30% (inverse) stress + 20% sleep (7-9 h ideal) + 20% activity (30+ min ideal).
Status: Good >= 70, Fair 50-69.9, At Risk < 50. Edit weights/thresholds in `wsv/analytics.py`.

## Demo script (5 minutes)
1. Launch `python main.py` - show the banner.
2. Option 1: enter bad values (mood `15`, stress `abc`, activity `-5`) and show them being rejected, then a valid entry.
3. Option 4 and 5: summary table, trend, warnings.
4. Option 8: import `data/sample_import_with_errors.csv` - 2 rows accepted, 5 rejected with reasons.
5. Exit, relaunch - the count persists (data/responses.json).
6. Option 7: export report; open `exports/report.md` and the PNG charts.

## Tests
```bash
python -m unittest discover -s tests
```

## Optional web UI
```bash
pip install streamlit pandas
streamlit run web_app.py
```
Reads/writes the same `data/responses.json`, so terminal and web stay in sync.

## Project layout
```
main.py                 terminal app
web_app.py              optional Streamlit UI
generate_sample_data.py sample CSV/JSON generator
wsv/                    models, validation, storage, analytics, reports, charts, ui
data/                   sample datasets (responses.json is created on first run)
exports/                reports and charts are written here
tests/                  unit tests
```
