"""OPTIONAL web interface (Streamlit) reusing the same core modules.

Run:  pip install streamlit pandas   then   streamlit run web_app.py
"""
import datetime as dt

import pandas as pd
import streamlit as st

from wsv import analytics, charts
from wsv.models import GROUPS, SurveyResponse
from wsv.storage import Store

st.set_page_config(page_title="Wellness Survey Visualizer", page_icon="🌿", layout="wide")
store = Store("data/responses.json")
st.title("🌿 Wellness Survey Visualizer")
page = st.sidebar.radio("Navigate", ["Dashboard", "Add response", "Browse & search"])

if page == "Dashboard":
    s = analytics.summarize(store.records)
    if not s["count"]:
        st.info("No data yet. Load the sample dataset from the terminal app (option 9) or add a response.")
    else:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Responses", s["count"])
        c2.metric("Avg mood", s["avg_mood"])
        c3.metric("Avg stress", s["avg_stress"])
        c4.metric("Wellness index", s["avg_index"], s["overall_status"])
        st.subheader("Weekly trend  -  " + s["trend"])
        st.line_chart(pd.DataFrame(s["weekly"], columns=["Week", "Index", "N"]).set_index("Week")["Index"])
        left, right = st.columns(2)
        left.subheader("Mood distribution")
        left.bar_chart(pd.Series(s["mood_distribution"]))
        right.subheader("Index by group")
        right.bar_chart(pd.Series({g: v["index"] for g, v in s["groups"].items()}))
        flags = analytics.warnings(store.records)
        st.subheader(f"Warnings ({len(flags)})")
        for rid, msg in flags:
            st.warning(f"Record #{rid}: {msg}")

elif page == "Add response":
    with st.form("add"):
        date = st.date_input("Date", dt.date.today(), max_value=dt.date.today())
        group = st.selectbox("Group", GROUPS)
        mood = st.slider("Mood", 1, 10, 5)
        stress = st.slider("Stress", 1, 10, 5)
        sleep = st.number_input("Hours slept", 0.0, 24.0, 7.0, 0.5)
        act = st.number_input("Active minutes", 0, 600, 30)
        comment = st.text_input("Comment (optional)", max_chars=200)
        if st.form_submit_button("Save"):
            rec = store.add(SurveyResponse(0, date.isoformat(), group, mood, stress, float(sleep), int(act), comment.strip()))
            st.success(f"Saved record #{rec.id} - index {analytics.wellness_index(rec)}")

else:
    kw = st.text_input("Keyword")
    grp = st.selectbox("Group", ["Any"] + GROUPS)
    found = analytics.search(store.records, kw, None if grp == "Any" else grp)
    df = pd.DataFrame([{**r.to_dict(), "index": analytics.wellness_index(r),
                        "status": analytics.status(analytics.wellness_index(r))} for r in found])
    st.dataframe(df, use_container_width=True)
