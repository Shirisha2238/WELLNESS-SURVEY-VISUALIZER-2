import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from wsv import analytics
from wsv.models import SurveyResponse
from wsv.storage import Store
from wsv.validation import parse_date, parse_float, parse_int, validate_record


def rec(**kw):
    base = dict(id=1, date="2026-01-05", group="Student", mood=5, stress=5, sleep_hours=7.5, activity_minutes=30, comment="")
    base.update(kw)
    return SurveyResponse(**base)


class ValidationTests(unittest.TestCase):
    def test_int_bounds(self):
        self.assertEqual(parse_int("10", 1, 10, "mood"), 10)
        self.assertEqual(parse_int("7.0", 1, 10, "mood"), 7)
        for bad in ("0", "11", "abc", "", "7.5", "nan", "inf"):
            with self.assertRaises(ValueError):
                parse_int(bad, 1, 10, "mood")

    def test_float(self):
        self.assertEqual(parse_float("24", 0, 24, "sleep"), 24.0)
        for bad in ("25", "-1", "x", "nan", "inf", ""):
            with self.assertRaises(ValueError):
                parse_float(bad, 0, 24, "sleep")

    def test_date(self):
        self.assertEqual(parse_date("2026-01-05"), "2026-01-05")
        for bad in ("05/01/2026", "2026-13-01", "", "1999-01-01", "2999-01-01"):
            with self.assertRaises(ValueError):
                parse_date(bad)

    def test_record(self):
        good, errs = validate_record(dict(date="2026-01-05", group="staff", mood="5", stress="5",
                                          sleep_hours="7", activity_minutes="20"))
        self.assertEqual(errs, [])
        self.assertEqual(good.group, "Staff")
        bad, errs = validate_record(dict(date="x", group="?", mood="99"))
        self.assertIsNone(bad)
        self.assertGreaterEqual(len(errs), 4)


class AnalyticsTests(unittest.TestCase):
    def test_index_bounds(self):
        best = analytics.wellness_index(rec(mood=10, stress=1, sleep_hours=8, activity_minutes=60))
        worst = analytics.wellness_index(rec(mood=1, stress=10, sleep_hours=0, activity_minutes=0))
        self.assertEqual(best, 100.0)
        self.assertEqual(worst, 0.0)

    def test_status(self):
        self.assertEqual(analytics.status(70), "Good")
        self.assertEqual(analytics.status(69.9), "Fair")
        self.assertEqual(analytics.status(49.9), "At Risk")

    def test_summary_and_trend(self):
        rows = [rec(id=1, date="2026-01-05", mood=3), rec(id=2, date="2026-01-12", mood=5),
                rec(id=3, date="2026-01-19", mood=8)]
        s = analytics.summarize(rows)
        self.assertEqual(s["count"], 3)
        self.assertTrue(s["trend"].startswith("Improving"))
        self.assertEqual(analytics.summarize([]), {"count": 0})

    def test_warnings_and_search(self):
        rows = [rec(id=1, stress=10, comment="Exam week"), rec(id=2, sleep_hours=2), rec(id=3)]
        flagged = {i for i, _ in analytics.warnings(rows)}
        self.assertEqual(flagged, {1, 2})
        self.assertEqual([r.id for r in analytics.search(rows, "exam")], [1])


class StorageTests(unittest.TestCase):
    def test_roundtrip_and_corruption(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "r.json")
            st = Store(path)
            st.add(rec(id=0))
            self.assertEqual(len(Store(path).records), 1)       # survives restart
            with open(path, "w") as fh:
                fh.write("{not json")
            st2 = Store(path)                                   # corrupt file handled
            self.assertEqual(st2.records, [])
            self.assertTrue(os.path.exists(path + ".corrupt"))

    def test_missing_file_and_bad_records(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "sub", "r.json")
            self.assertEqual(Store(path).records, [])
            with open(path, "w") as fh:
                json.dump({"responses": [{"id": 1, "date": "bad"}, "junk"]}, fh)
            st = Store(path)
            self.assertEqual(st.records, [])
            self.assertTrue(st.load_notes)

    def test_csv_import_error_log(self):
        with tempfile.TemporaryDirectory() as d:
            src = os.path.join(d, "in.csv")
            with open(src, "w") as fh:
                fh.write("id,date,group,mood,stress,sleep_hours,activity_minutes,comment\n"
                         "1,2026-01-05,Student,5,5,7,30,ok\n2,2026-01-05,Student,50,5,7,30,bad\n")
            st = Store(os.path.join(d, "r.json"))
            log = os.path.join(d, "err.log")
            added, bad = st.import_csv(src, log)
            self.assertEqual((added, bad), (1, 1))
            self.assertIn("line 3", open(log).read())


if __name__ == "__main__":
    unittest.main()
