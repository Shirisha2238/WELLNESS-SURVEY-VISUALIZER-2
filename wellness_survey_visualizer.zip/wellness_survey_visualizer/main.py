#!/usr/bin/env python3
"""Wellness Survey Visualizer - menu-driven terminal application."""
import datetime as dt
import os

from wsv import analytics, charts, reports, ui
from wsv.models import GROUPS, LIMITS, MAX_COMMENT, SurveyResponse
from wsv.storage import Store
from wsv.validation import parse_comment, parse_date, parse_float, parse_group, parse_int

DATA_FILE = os.path.join("data", "responses.json")
EXPORT_DIR = "exports"
HEADERS = ["ID", "Date", "Group", "Mood", "Stress", "Sleep", "Active", "Index", "Status", "Comment"]


def row(r: SurveyResponse):
    idx = analytics.wellness_index(r)
    return [r.id, r.date, r.group, r.mood, r.stress, r.sleep_hours, r.activity_minutes, idx,
            analytics.status(idx), r.comment]


def add_entry(store: Store):
    ui.heading("New anonymous response")
    print("Tip: no names or personal details - this survey is anonymous.\n")
    date = ui.ask("Date (YYYY-MM-DD)", parse_date, default=dt.date.today().isoformat())
    print("Groups: " + ", ".join(f"{i}={g}" for i, g in enumerate(GROUPS, 1)))
    group = ui.ask("Group (name or number)", parse_group)
    mood = ui.ask("Mood 1-10", lambda v: parse_int(v, *LIMITS["mood"], "mood"))
    stress = ui.ask("Stress 1-10", lambda v: parse_int(v, *LIMITS["stress"], "stress"))
    sleep = ui.ask("Hours slept (0-24)", lambda v: parse_float(v, *LIMITS["sleep_hours"], "sleep"))
    act = ui.ask("Active minutes today (0-600)", lambda v: parse_int(v, *LIMITS["activity_minutes"], "activity"))
    comment = ui.ask(f"Comment (optional, max {MAX_COMMENT} chars)", parse_comment, allow_blank=True)
    rec = store.add(SurveyResponse(0, date, group, mood, stress, sleep, act, comment))
    idx = analytics.wellness_index(rec)
    st = analytics.status(idx)
    print(ui.c(f"\n✓ Saved as record #{rec.id}. Wellness index {idx} -> ", "green") + ui.c(st, ui.STATUS_COLOR[st]))
    for _id, msg in analytics.warnings([rec]):
        print(ui.c(f"  ⚠ {msg}", "yellow"))


def view_all(store: Store):
    ui.heading("All responses")
    ui.paginate(HEADERS, [row(r) for r in store.records])


def search_records(store: Store):
    ui.heading("Search")
    kw = input("Keyword in comment/group (blank = any): ").strip()
    grp = ui.ask("Group filter (blank = any)", parse_group, allow_blank=True) or None
    d_from = ui.ask("From date (blank = any)", lambda v: parse_date(v, True), allow_blank=True) or None
    d_to = ui.ask("To date (blank = any)", lambda v: parse_date(v, True), allow_blank=True) or None
    st = ui.ask("Status Good/Fair/At Risk (blank = any)",
                lambda v: next((s for s in ("Good", "Fair", "At Risk") if s.lower() == v.lower()), None)
                or (_ for _ in ()).throw(ValueError("choose Good, Fair or At Risk")),
                allow_blank=True) or None
    found = analytics.search(store.records, kw, grp, d_from, d_to, st)
    print(f"\n{len(found)} match(es)")
    ui.paginate(HEADERS, [row(r) for r in found])


def show_summary(store: Store):
    ui.heading("Executive summary")
    s = analytics.summarize(store.records)
    for line in reports.summary_lines(s):
        print(line)
    if s["count"]:
        print()
        print(ui.table(["Group", "N", "Mood", "Stress", "Index"],
                       [[g, v["count"], v["mood"], v["stress"], v["index"]] for g, v in s["groups"].items()]))
        print()
        print(ui.table(["Week", "Avg index", "N"], [list(w) for w in s["weekly"]]))
        flags = analytics.warnings(store.records)
        print(ui.c(f"\n⚠ {len(flags)} warning(s) - see option 5", "yellow") if flags else "\nNo warnings.")


def show_warnings(store: Store):
    ui.heading("Threshold warnings")
    flags = analytics.warnings(store.records)
    if not flags:
        print(ui.c("✓ No warnings.", "green"))
    for rid, msg in flags:
        print(ui.c(f"⚠ record #{rid}: {msg}", "yellow"))


def make_charts(store: Store):
    ui.heading("Charts")
    try:
        files = charts.make_charts(analytics.summarize(store.records), EXPORT_DIR)
    except ImportError as exc:
        print(ui.c(f"Charts unavailable: {exc}", "red"))
        return
    print("No data to chart." if not files else ui.c("✓ Saved:\n  " + "\n  ".join(files), "green"))


def export_all(store: Store):
    ui.heading("Export reports")
    s = analytics.summarize(store.records)
    try:
        chart_files = charts.make_charts(s, EXPORT_DIR)
    except ImportError:
        chart_files = []
        print(ui.c("matplotlib missing - exporting without charts.", "yellow"))
    paths = [
        reports.export_markdown(store.records, s, os.path.join(EXPORT_DIR, "report.md"), chart_files),
        reports.export_audit_log(store.records, s, os.path.join(EXPORT_DIR, "audit_log.txt")),
        reports.export_summary_csv(store.records, os.path.join(EXPORT_DIR, "summary.csv")),
    ] + chart_files
    print(ui.c("✓ Exported:\n  " + "\n  ".join(paths), "green"))


def import_csv(store: Store):
    ui.heading("Bulk CSV import")
    path = input("CSV path [data/sample_import_with_errors.csv]: ").strip() or "data/sample_import_with_errors.csv"
    try:
        added, bad = store.import_csv(path, os.path.join(EXPORT_DIR, "import_errors.log"))
    except (OSError, ValueError) as exc:
        print(ui.c(f"✗ Import failed: {exc}", "red"))
        return
    print(ui.c(f"✓ Imported {added} row(s); rejected {bad}.", "green" if not bad else "yellow"))
    if bad:
        print(f"  Row-level details: {os.path.join(EXPORT_DIR, 'import_errors.log')}")


def load_sample(store: Store):
    if store.records and not ui.confirm("This replaces existing data. Continue"):
        return
    store.replace_all([])
    try:
        added, _bad = store.import_csv(os.path.join("data", "sample_responses.csv"))
    except (OSError, ValueError) as exc:
        print(ui.c(f"✗ Could not load sample data: {exc}", "red"))
        return
    print(ui.c(f"✓ Loaded {added} sample responses.", "green"))


MENU = [
    ("1", "Add new response", add_entry),
    ("2", "View all responses", view_all),
    ("3", "Search / filter", search_records),
    ("4", "Executive summary", show_summary),
    ("5", "Threshold warnings", show_warnings),
    ("6", "Generate charts (PNG)", make_charts),
    ("7", "Export reports (MD / TXT / CSV)", export_all),
    ("8", "Bulk import from CSV", import_csv),
    ("9", "Load sample dataset", load_sample),
]


def main():
    store = Store(DATA_FILE)
    ui.banner()
    for note in store.load_notes:
        print(ui.c(f"ℹ {note}", "yellow"))
    print(f"{len(store.records)} response(s) loaded.")
    actions = {k: fn for k, _, fn in MENU}
    while True:
        print()
        for k, label, _ in MENU:
            print(f"  {ui.c(k, 'cyan')}. {label}")
        print(f"  {ui.c('0', 'cyan')}. Exit")
        try:
            choice = input("\nChoose an option: ").strip()
            if choice == "0":
                print("Goodbye - your data is saved.")
                return
            if choice in actions:
                actions[choice](store)
            else:
                print(ui.c("✗ Please enter a number from the menu.", "red"))
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye - your data is saved.")
            return
        except Exception as exc:        # last-resort guard so a demo never crashes
            print(ui.c(f"✗ Unexpected error: {exc}", "red"))


if __name__ == "__main__":
    main()
